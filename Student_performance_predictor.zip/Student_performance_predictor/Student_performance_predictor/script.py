import tkinter as tk
from tkinter import filedialog, messagebox
import math
import csv
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def load_data(filename):
    data = []
    with open(filename, 'r') as f:
        reader = csv.reader(f, delimiter='\t')
        next(reader)
        for row in reader:
            sample = {
                'study_time': float(row[0]),
                'failures': float(row[1]),
                'absences': float(row[2]),
                'label': row[3]
            }
            data.append(sample)
    return data

def mean(values):
    return sum(values) / len(values)

def variance(values, mean_val):
    return sum((x - mean_val) ** 2 for x in values) / len(values)

def gaussian_prob(x, mean, var):
    if var == 0:
        return 1.0 if x == mean else 0.0001
    exponent = math.exp(-((x - mean) ** 2) / (2 * var))
    return (1 / math.sqrt(2 * math.pi * var)) * exponent

def train(data):
    classes = {}
    for sample in data:
        label = sample['label']
        if label not in classes:
            classes[label] = {'study_time': [], 'failures': [], 'absences': [], 'count': 0}
        classes[label]['study_time'].append(sample['study_time'])
        classes[label]['failures'].append(sample['failures'])
        classes[label]['absences'].append(sample['absences'])
        classes[label]['count'] += 1

    total_samples = len(data)
    model = {}
    for label, stats in classes.items():
        model[label] = {
            'prior': stats['count'] / total_samples,
            'study_time': {
                'mean': mean(stats['study_time']),
                'var': variance(stats['study_time'], mean(stats['study_time']))
            },
            'failures': {
                'mean': mean(stats['failures']),
                'var': variance(stats['failures'], mean(stats['failures']))
            },
            'absences': {
                'mean': mean(stats['absences']),
                'var': variance(stats['absences'], mean(stats['absences']))
            }
        }
    return model

def evaluate(model, test_data):
    correct = 0
    incorrect = 0
    result_counts = {}
    for sample in test_data:
        predicted = predict(model, sample)
        true_label = sample['label']
        if predicted == true_label:
            correct += 1
        else:
            incorrect += 1
        result_counts[predicted] = result_counts.get(predicted, 0) + 1
    accuracy = (correct / (correct + incorrect)) * 100
    return correct, incorrect, accuracy, result_counts

def predict(model, sample):
    probabilities = {}
    for label, stats in model.items():
        prob = math.log(stats['prior'])
        prob += math.log(gaussian_prob(sample['study_time'], stats['study_time']['mean'], stats['study_time']['var']))
        prob += math.log(gaussian_prob(sample['failures'], stats['failures']['mean'], stats['failures']['var']))
        prob += math.log(gaussian_prob(sample['absences'], stats['absences']['mean'], stats['absences']['var']))
        probabilities[label] = prob
    return max(probabilities, key=probabilities.get)

class StudentPredictorApp:
    def __init__(self, master):
        self.master = master
        master.title("Student Performance Predictor")
        master.geometry("620x620")

        self.model = None

        tk.Label(master, text="Enter Study Time (hours/day):").pack()
        self.study_time_entry = tk.Entry(master)
        self.study_time_entry.pack()

        tk.Label(master, text="Enter Number of Past Failures:").pack()
        self.failures_entry = tk.Entry(master)
        self.failures_entry.pack()

        tk.Label(master, text="Enter Number of Absences:").pack()
        self.absences_entry = tk.Entry(master)
        self.absences_entry.pack()

        tk.Button(master, text="Train Model", command=self.train_model).pack(pady=5)
        tk.Button(master, text="Predict Result", command=self.predict_result).pack(pady=5)
        tk.Button(master, text="Load and Evaluate Test Data", command=self.load_test_data).pack(pady=5)

        self.result_label = tk.Label(master, text="", font=("Helvetica", 12, "bold"))
        self.result_label.pack(pady=10)

        self.chart_frame = tk.Frame(master)
        self.chart_frame.pack(fill="both", expand=True)

    def train_model(self):
        file_path = filedialog.askopenfilename(title="Select Training Dataset", filetypes=[("TSV Files", "*.tsv")])
        if file_path:
            data = load_data(file_path)
            self.model = train(data)
            messagebox.showinfo("Model Trained", "Model training completed successfully.")

    def predict_result(self):
        if self.model is None:
            messagebox.showwarning("No Model", "Please train the model first.")
            return
        try:
            sample = {
                'study_time': float(self.study_time_entry.get()),
                'failures': float(self.failures_entry.get()),
                'absences': float(self.absences_entry.get()),
                'label': 'unknown'
            }

            probabilities = {}
            for label, stats in self.model.items():
                prob = math.log(stats['prior'])
                prob += math.log(gaussian_prob(sample['study_time'], stats['study_time']['mean'], stats['study_time']['var']))
                prob += math.log(gaussian_prob(sample['failures'], stats['failures']['mean'], stats['failures']['var']))
                prob += math.log(gaussian_prob(sample['absences'], stats['absences']['mean'], stats['absences']['var']))
                probabilities[label] = prob

            prediction = max(probabilities, key=probabilities.get)
            self.result_label.config(text=f"Predicted Result: {prediction.upper()}")

            exp_probs = {k: math.exp(v) for k, v in probabilities.items()}
            total = sum(exp_probs.values())
            normalized_probs = {k: v / total for k, v in exp_probs.items()}
            self.show_prediction_bar(normalized_probs)

        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid numerical values.")

    def load_test_data(self):
        if self.model is None:
            messagebox.showwarning("No Model", "Please train the model first.")
            return
        file_path = filedialog.askopenfilename(title="Select Test Dataset", filetypes=[("TSV Files", "*.tsv")])
        if file_path:
            test_data = load_data(file_path)
            correct, incorrect, accuracy, result_counts = evaluate(self.model, test_data)
            self.result_label.config(
                text=f"Accuracy: {accuracy:.2f}%\nCorrect: {correct} | Incorrect: {incorrect}")
            self.show_pie_chart(result_counts)

    def show_prediction_bar(self, probabilities):
        for widget in self.chart_frame.winfo_children():
            widget.destroy()
        labels = list(probabilities.keys())
        sizes = [probabilities[k] * 100 for k in labels]
        fig, ax = plt.subplots()
        ax.bar(labels, sizes, color=['green', 'red'])
        ax.set_title("Prediction Confidence")
        ax.set_ylabel("Confidence (%)")
        ax.set_ylim(0, 100)
        chart = FigureCanvasTkAgg(fig, master=self.chart_frame)
        chart.get_tk_widget().pack(fill="both", expand=True)
        chart.draw()

    def show_pie_chart(self, result_counts):
        for widget in self.chart_frame.winfo_children():
            widget.destroy()
        labels = list(result_counts.keys())
        sizes = [result_counts[k] for k in labels]
        fig, ax = plt.subplots()
        ax.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
        ax.axis('equal')
        ax.set_title("Test Prediction Distribution")
        chart = FigureCanvasTkAgg(fig, master=self.chart_frame)
        chart.get_tk_widget().pack(fill="both", expand=True)
        chart.draw()

if __name__ == "__main__":
    root = tk.Tk()
    app = StudentPredictorApp(root)
    root.mainloop()
