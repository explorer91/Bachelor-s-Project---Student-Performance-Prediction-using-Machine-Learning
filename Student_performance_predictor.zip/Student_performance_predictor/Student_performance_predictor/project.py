import tkinter as tk
from tkinter import filedialog, messagebox, font
import math
import csv
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import os

# Data and ML logic 
def load_data(filename):
    data = []
    with open(filename, 'r') as f:
        reader = csv.reader(f, delimiter='\t')
        next(reader)
        for row in reader:
            sample = {
                'study_time': float(row[0]),
                'failures': float(row[1]),
                'absences': float(row[2]),
                'label': row[3]
            }
            data.append(sample)
    return data

def mean(values):
    return sum(values) / len(values)

def variance(values, mean_val):
    return sum((x - mean_val) ** 2 for x in values) / len(values)

def gaussian_prob(x, mean, var):
    if var == 0:
        return 1.0 if x == mean else 0.0001
    exponent = math.exp(-((x - mean) ** 2) / (2 * var))
    return (1 / math.sqrt(2 * math.pi * var)) * exponent

def train(data):
    classes = {}
    for sample in data:
        label = sample['label']
        if label not in classes:
            classes[label] = {'study_time': [], 'failures': [], 'absences': [], 'count': 0}
        classes[label]['study_time'].append(sample['study_time'])
        classes[label]['failures'].append(sample['failures'])
        classes[label]['absences'].append(sample['absences'])
        classes[label]['count'] += 1

    total_samples = len(data)
    model = {}
    for label, stats in classes.items():
        model[label] = {
            'prior': stats['count'] / total_samples,
            'study_time': {
                'mean': mean(stats['study_time']),
                'var': variance(stats['study_time'], mean(stats['study_time']))
            },
            'failures': {
                'mean': mean(stats['failures']),
                'var': variance(stats['failures'], mean(stats['failures']))
            },
            'absences': {
                'mean': mean(stats['absences']),
                'var': variance(stats['absences'], mean(stats['absences']))
            }
        }
    return model

def evaluate(model, test_data):
    correct = 0
    incorrect = 0
    result_counts = {}
    confusion = {}
    for sample in test_data:
        predicted = predict(model, sample)
        true_label = sample['label']
        if predicted == true_label:
            correct += 1
        else:
            incorrect += 1
        result_counts[predicted] = result_counts.get(predicted, 0) + 1
        confusion[(true_label, predicted)] = confusion.get((true_label, predicted), 0) + 1
    accuracy = (correct / (correct + incorrect)) * 100
    return correct, incorrect, accuracy, result_counts, confusion

def predict(model, sample):
    probabilities = {}
    for label, stats in model.items():
        prob = math.log(stats['prior'])
        prob += math.log(gaussian_prob(sample['study_time'], stats['study_time']['mean'], stats['study_time']['var']))
        prob += math.log(gaussian_prob(sample['failures'], stats['failures']['mean'], stats['failures']['var']))
        prob += math.log(gaussian_prob(sample['absences'], stats['absences']['mean'], stats['absences']['var']))
        probabilities[label] = prob
    return max(probabilities, key=probabilities.get)


class StudentPredictorApp:
    def __init__(self, master):
        self.master = master
        master.title("Student Performance Predictor")
        master.geometry("750x800")
        master.configure(bg="#f5f6fa")

        # Fonts
        self.title_font = font.Font(family="Helvetica", size=18, weight="bold")
        self.label_font = font.Font(family="Arial", size=12)
        self.entry_font = font.Font(family="Arial", size=12)
        self.button_font = font.Font(family="Arial", size=11, weight="bold")

        self.model = None
        self.last_prediction = None

        # --- Title ---
        title_label = tk.Label(master, text="Student Performance Predictor", font=self.title_font, bg="#f5f6fa", fg="#2f3640")
        title_label.pack(pady=(15, 10))

        # --- Input Frame ---
        input_frame = tk.Frame(master, bg="white", bd=2, relief="groove")
        input_frame.pack(padx=20, pady=10, fill="x")

        # Study Time
        study_label = tk.Label(input_frame, text="Study Time (hours/day):", font=self.label_font, bg="white")
        study_label.grid(row=0, column=0, sticky="w", padx=10, pady=10)
        self.study_time_entry = tk.Entry(input_frame, font=self.entry_font, width=20, bd=2, relief="ridge")
        self.study_time_entry.grid(row=0, column=1, padx=10, pady=10)

        # Failures
        failures_label = tk.Label(input_frame, text="Number of Past Failures:", font=self.label_font, bg="white")
        failures_label.grid(row=1, column=0, sticky="w", padx=10, pady=10)
        self.failures_entry = tk.Entry(input_frame, font=self.entry_font, width=20, bd=2, relief="ridge")
        self.failures_entry.grid(row=1, column=1, padx=10, pady=10)

        # Absences
        absences_label = tk.Label(input_frame, text="Number of Absences:", font=self.label_font, bg="white")
        absences_label.grid(row=2, column=0, sticky="w", padx=10, pady=10)
        self.absences_entry = tk.Entry(input_frame, font=self.entry_font, width=20, bd=2, relief="ridge")
        self.absences_entry.grid(row=2, column=1, padx=10, pady=10)

        # --- Buttons Frame ---
        buttons_frame = tk.Frame(master, bg="#f5f6fa")
        buttons_frame.pack(pady=15)

        btn_params = {"font": self.button_font, "width": 18, "bd": 0, "highlightthickness": 0, "relief": "ridge", "cursor": "hand2"}

        self.train_btn = tk.Button(buttons_frame, text="Train Model", bg="#44bd32", fg="white", **btn_params, command=self.train_model)
        self.train_btn.grid(row=0, column=0, padx=8, pady=8)

        self.predict_btn = tk.Button(buttons_frame, text="Predict Result", bg="#273c75", fg="white", **btn_params, command=self.predict_result)
        self.predict_btn.grid(row=0, column=1, padx=8, pady=8)

        self.clear_btn = tk.Button(buttons_frame, text="Clear Inputs", bg="#e1b12c", fg="white", **btn_params, command=self.clear_inputs)
        self.clear_btn.grid(row=0, column=2, padx=8, pady=8)

        self.save_btn = tk.Button(buttons_frame, text="Save Prediction", bg="#40739e", fg="white", **btn_params, command=self.save_prediction)
        self.save_btn.grid(row=1, column=0, padx=8, pady=8)

        self.stats_btn = tk.Button(buttons_frame, text="Model Statistics", bg="#8c7ae6", fg="white", **btn_params, command=self.show_model_stats)
        self.stats_btn.grid(row=1, column=1, padx=8, pady=8)

        self.visual_btn = tk.Button(buttons_frame, text="Visualize Features", bg="#e84118", fg="white", **btn_params, command=self.visualize_features)
        self.visual_btn.grid(row=1, column=2, padx=8, pady=8)

        self.eval_btn = tk.Button(buttons_frame, text="Load & Evaluate Test Data", bg="#0097e6", fg="white", **btn_params, command=self.load_test_data)
        self.eval_btn.grid(row=2, column=0, columnspan=3, pady=12, ipadx=30)

        # --- Result Display ---
        self.result_label = tk.Label(master, text="", font=("Helvetica", 14, "bold"), bg="#f5f6fa", fg="#2f3640")
        self.result_label.pack(pady=15)

        # --- Chart Frame ---
        self.chart_frame = tk.Frame(master, bg="white", bd=2, relief="groove", height=300)
        self.chart_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # Hover effect on buttons
        for btn in [self.train_btn, self.predict_btn, self.clear_btn, self.save_btn, self.stats_btn, self.visual_btn, self.eval_btn]:
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#718093"))
            btn.bind("<Leave>", lambda e, b=btn: self.reset_button_color(b))

    def reset_button_color(self, btn):
        color_map = {
            self.train_btn: "#44bd32",
            self.predict_btn: "#273c75",
            self.clear_btn: "#e1b12c",
            self.save_btn: "#40739e",
            self.stats_btn: "#8c7ae6",
            self.visual_btn: "#e84118",
            self.eval_btn: "#0097e6"
        }
        btn.config(bg=color_map.get(btn, "#718093"))

    def train_model(self):
        filename = filedialog.askopenfilename(title="Select Training Data File",filetypes=(("TSV files", "*.tsv"), ("All files", "*.*")))


        if not filename:
            return
        try:
            data = load_data(filename)
            self.model = train(data)
            messagebox.showinfo("Training", f"Model trained successfully with {len(data)} samples.")
            self.result_label.config(text="Model trained successfully.", fg="#44bd32")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to train model: {e}")

    def predict_result(self):
        if not self.model:
            messagebox.showwarning("No Model", "Train the model first.")
            return
        try:
            study_time = float(self.study_time_entry.get())
            failures = float(self.failures_entry.get())
            absences = float(self.absences_entry.get())
            sample = {'study_time': study_time, 'failures': failures, 'absences': absences}
            prediction = predict(self.model, sample)
            self.last_prediction = prediction
            self.result_label.config(text=f"Predicted Performance: {prediction}", fg="#44bd32")
        except ValueError:
            messagebox.showwarning("Input Error", "Please enter valid numeric values.")
        except Exception as e:
            messagebox.showerror("Prediction Error", f"An error occurred:\n{e}")

    def clear_inputs(self):
        self.study_time_entry.delete(0, tk.END)
        self.failures_entry.delete(0, tk.END)
        self.absences_entry.delete(0, tk.END)
        self.result_label.config(text="")
        self.last_prediction = None
        for widget in self.chart_frame.winfo_children():
            widget.destroy()

    def save_prediction(self):
        if not self.last_prediction:
            messagebox.showwarning("No Prediction", "No prediction to save. Predict first.")
            return
        save_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt")])
        if save_path:
            try:
                with open(save_path, "a") as f:
                    line = f"Study Time: {self.study_time_entry.get()}, Failures: {self.failures_entry.get()}, Absences: {self.absences_entry.get()}, Prediction: {self.last_prediction}\n"
                    f.write(line)
                messagebox.showinfo("Saved", "Prediction saved successfully.")
            except Exception as e:
                messagebox.showerror("Save Error", f"Could not save prediction: {e}")

    def show_model_stats(self):
        if not self.model:
            messagebox.showwarning("No Model", "Train the model first.")
            return
        stats = ""
        for label, stats_dict in self.model.items():
            stats += f"Class: {label}\n"
            stats += f"  Prior Probability: {stats_dict['prior']:.3f}\n"
            stats += f"  Study Time Mean/Var: {stats_dict['study_time']['mean']:.2f}/{stats_dict['study_time']['var']:.2f}\n"
            stats += f"  Failures Mean/Var: {stats_dict['failures']['mean']:.2f}/{stats_dict['failures']['var']:.2f}\n"
            stats += f"  Absences Mean/Var: {stats_dict['absences']['mean']:.2f}/{stats_dict['absences']['var']:.2f}\n\n"
        messagebox.showinfo("Model Statistics", stats)

    def visualize_features(self):
        if not self.model:
            messagebox.showwarning("No Model", "Train the model first.")
            return

        # Clear previous plots
        for widget in self.chart_frame.winfo_children():
            widget.destroy()

        labels = list(self.model.keys())
        study_means = [self.model[label]['study_time']['mean'] for label in labels]
        failures_means = [self.model[label]['failures']['mean'] for label in labels]
        absences_means = [self.model[label]['absences']['mean'] for label in labels]

        fig, ax = plt.subplots(figsize=(7, 4))
        width = 0.25
        x = range(len(labels))

        ax.bar([p - width for p in x], study_means, width=width, label="Study Time Mean")
        ax.bar(x, failures_means, width=width, label="Failures Mean")
        ax.bar([p + width for p in x], absences_means, width=width, label="Absences Mean")

        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.set_ylabel("Mean Values")
        ax.set_title("Feature Means by Class")
        ax.legend()

        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)

    def load_test_data(self):
        if not self.model:
            messagebox.showwarning("No Model", "Train the model first.")
            return
        filename = filedialog.askopenfilename(title="Select Training Data File",filetypes=(("TSV files", "*.tsv"), ("All files", "*.*")))
        if not filename:
            return
        try:
            test_data = load_data(filename)
            correct, incorrect, accuracy, result_counts, confusion = evaluate(self.model, test_data)

            # Clear previous plot
            for widget in self.chart_frame.winfo_children():
                widget.destroy()

            # Show summary
            summary_text = (f"Test Data Loaded: {len(test_data)} samples\n"
                            f"Correct Predictions: {correct}\n"
                            f"Incorrect Predictions: {incorrect}\n"
                            f"Accuracy: {accuracy:.2f}%")
            self.result_label.config(text=summary_text, fg="#273c75")

            # Plot confusion matrix heatmap
            # Extract unique labels from confusion keys
            unique_labels = sorted(set([label for pair in confusion.keys() for label in pair]))

            matrix = []
            for true_label in unique_labels:
                row = []
                for pred_label in unique_labels:
                    row.append(confusion.get((true_label, pred_label), 0))
                matrix.append(row)

            fig, ax = plt.subplots(figsize=(7, 5))
            cax = ax.matshow(matrix, cmap=plt.cm.Blues)
            plt.colorbar(cax)

            ax.set_xticks(range(len(unique_labels)))
            ax.set_yticks(range(len(unique_labels)))
            ax.set_xticklabels(unique_labels)
            ax.set_yticklabels(unique_labels)

            ax.set_xlabel("Predicted")
            ax.set_ylabel("Actual")
            ax.set_title("Confusion Matrix")

            # Add text inside squares
            for i in range(len(unique_labels)):
                for j in range(len(unique_labels)):
                    ax.text(j, i, matrix[i][j], ha="center", va="center", color="red" if matrix[i][j] > 0 else "black")

            fig.tight_layout()

            canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to evaluate test data: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = StudentPredictorApp(root)
    root.mainloop()
